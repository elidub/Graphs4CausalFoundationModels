    
from pathlib import Path
from tqdm import tqdm
import dill as pkl
from sklearn.metrics import mean_squared_error
import sys
import os
sys.path.append(os.path.abspath("/work/dlclarge2/robertsj-dofm"))
from generate_plant_data import CID_Benchmark
import numpy as np

def mean_integrated_squared_error(t, y_true, y_pred):
    mise = 0
    for s in np.unique(t):
        mise += mean_squared_error(y_true[t == s], y_pred=y_pred[t == s])
    return mise

def avg_mean_integrated_squared_error(t, y_true, y_pred):
    return 0

def evaluate_pipeline(exp_name, model_pipeline, model, args):
    exp_dir = Path(f"/work/dlclarge2/robertsj-dofm/results/plants/{exp_name}")
    Path(exp_dir).mkdir(parents=True, exist_ok=True)

    data_dir = Path("/work/dlclarge2/robertsj-dofm/plant_data")
    with open(str(data_dir  / Path(args.dataset)) + ".pkl", "rb") as f:
        cid_benchmark = pkl.load(f)

    for dataset_index, cid_dataset in tqdm(enumerate(cid_benchmark.realizations)):
        
        cid_pred = model_pipeline(model, cid_dataset)
        mise = mean_integrated_squared_error(cid_dataset.t_test, cid_dataset.true_cid, cid_pred)
        amise = avg_mean_integrated_squared_error(cid_dataset.t_test, cid_dataset.true_cid, cid_pred)

        print(f"MISE: {mise}")
        print(f"ATE Rel. Err: {amise}")

        result_dict = {
            "model": args.model, 
            "dataset": args.dataset, 
            "realization": dataset_index, 
            "mise": mise,
            "cate_preds": cid_pred,
            "amise": amise,
            "cid_dataset": cid_dataset
        }

        with open(exp_dir / f"{args.model}_{args.dataset}_{dataset_index}", "wb") as f:
            pkl.dump(result_dict, f)